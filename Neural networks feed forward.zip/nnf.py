#!/usr/bin/env python
# coding: utf-8

# In[2]:


import numpy as np
from numpy import random
from PIL import Image
import numpy


# In[3]:


file=open('downgesture_train.list.txt')
direct=[]
Y=[]
X=[]
for d in file:
    d=d.strip('\n')
    direct.append(d)

for d in direct:
    x_0=np.array([1])
    im = Image.open(d)
    im = im.resize((4,4))
    np_im = numpy.array(im).flatten()
    x_t=np.append(x_0, np_im)
    X.append(x_t)
    if 'down' in d:
        label=0
    else:
        label=1
    Y.append(label)    
y_train=np.array(Y).reshape(len(Y),1)
x_train=np.array(X)


# In[4]:


file=open('downgesture_test.list.txt')
direct=[]
Y=[]
X=[]
for d in file:
    d=d.strip('\n')
    direct.append(d)

for d in direct:
    x_0=np.array([1])
    im = Image.open(d)
    im = im.resize((4,4))
    np_im = numpy.array(im).flatten()
    x_t=np.append(x_0, np_im)
    X.append(x_t)
    if 'down' in d:
        label=0
    else:
        label=1
    Y.append(label)    
y_test=np.array(Y).reshape(len(Y),1)
x_test=np.array(X)


# In[6]:


def sigmoid(X):
    return 1 / (1 + np.exp(-X))

# Activation prime function
def sigmoid_derivative(x):
    return x * (1.0 - x)
class NeuralNetwork:
    def __init__(self, x, y):
        self.input      = x
        self.weights1   = np.random.rand(self.input.shape[1],100) 
        self.weights2   = np.random.rand(100,1)                 
        self.y          = y
        self.output     = np.zeros(self.y.shape)

    def feedforward(self):
        self.layer1 = sigmoid(np.dot(self.input, self.weights1))
        self.output = sigmoid(np.dot(self.layer1, self.weights2))

    def backprop(self):
        # chain rule 
        d_weights2 = np.dot(self.layer1.T, (2*(self.y - self.output) * sigmoid_derivative(self.output)))
        d_weights1 = np.dot(self.input.T,  (np.dot(2*(self.y - self.output) * sigmoid_derivative(self.output), self.weights2.T) * sigmoid_derivative(self.layer1)))

        # update the weights 
        self.weights1 +=0.1* d_weights1
        self.weights2 +=0.1* d_weights2
    

if __name__ == "__main__":
    X = x_train
    y = y_train
    nn = NeuralNetwork(X,y)

    for i in range(1000):
        nn.feedforward()
        nn.backprop()        
    
def predict(X_test):
        # Forward Propagation
        h1_ = np.dot(X_test, nn.weights1) 
        h1 = sigmoid(h1_)
        y_ = np.dot(h1, nn.weights2) 
        y = sigmoid(y_)
        return y
y_pred=predict(x_test)
print(y_pred)
#print(1-np.sum(np.power(y_pred - y_test, 2))/len(x_test))
num_correct = 0
for i in range(len(y_pred)):
    if y_pred[i] == y_test[i]:
        num_correct += 1
acc=num_correct/(len(y_pred))
print(acc)


# In[ ]:





# In[ ]:




