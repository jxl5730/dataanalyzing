#!/usr/bin/env python
# coding: utf-8

# In[2]:


import re
file=open('dt_data.txt')
dataset=[]
for row in file:
    if '('in row:
        header=row.lstrip('(').rstrip(')\n').split(', ')
    elif ':' in row:
        line=str(re.findall('\: (.*?)\;',row)).lstrip('[\'').rstrip('\']').split(', ')
        dataset.append(line)
dataset


# In[3]:


def unique_vals(rows,col):
    vals=[]
    return set([row[col] for row in rows])
#unique_vals(dataset, 0)


# In[10]:


class Que:
    def __init__(self,column,value):
        self.column=column
        self.value=value
    def __repr__(self):
        return f'Is {header[self.column]} {self.value}?'
    def match(self,rows):
        val=rows[self.column]
        return val==self.value
#q=Que(0, 'High')
#print(q,q.match(dataset[0]))


# In[11]:


def part(rows,question):
    true_rows=[]
    false_rows=[]
    for row in rows:
        if question.match(row):
            true_rows.append(row)
        else:
            false_rows.append(row)
    return true_rows, false_rows
#true_rows, false_rows = part(dataset, Que(0, 'High'))
#true_rows            


# In[12]:


def label_counts(rows):
    counts={}
    for row in rows:
        label=row[-1]
        if label not in counts:
            counts[label]=1
        else:
            counts[label]+=1
    return counts
#label_counts(dataset)


# In[13]:


import math
def entropy(rows):
    counts=label_counts(rows)
    entro=0
    for lb in counts:
        prob=counts[lb]/float(len(rows))
        entro-=prob*math.log(prob,2)
    return entro


# In[14]:


def info_gain(left, right, curr_entropy):
    p=float(len(left))/(len(left)+len(right))
    return curr_entropy-p*entropy(left)-(1-p)*entropy(right)
#curr_entropy=entropy(dataset)
#true_rows, false_rows = part(dataset, Que(0, 'High'))
#info_gain(true_rows, false_rows, curr_entropy)


# In[15]:


def find_best_question(rows):
    best_gain=0
    best_question=None
    curr_entropy=entropy(rows)
    attribute_n=len(rows[0])-1
    for col in range(attribute_n):
        values=unique_vals(rows,col)
        for val in values:
            question=Que(col,val)
            true_rows,false_rows=part(rows, question)
            if len(true_rows)==0 or len(false_rows)==0:
                continue
            gain=info_gain(true_rows,false_rows,curr_entropy)
            if gain>=best_gain:
                best_gain=gain
                best_question=question
    return best_gain, best_question
#find_best_question(dataset)


# In[35]:


class Leaf:
    def __init__(self,rows):
        self.predictions=label_counts(rows)


# In[39]:


class TreeNode:
    def __init__(self,question,true_branch,false_branch):
        self.question=question
        self.true_branch=true_branch
        self.false_branch=false_branch
        #self.entropy=entropy


# In[41]:


def build_tree(rows):
    gain,question=find_best_question(rows)
    if gain==0:
        return Leaf(rows)
    true_rows,false_rows=part(rows, question)
    true_branch=build_tree(true_rows)
    false_branch=build_tree(false_rows)
    return TreeNode(question,true_branch,false_branch)#entropy)


# In[42]:


def print_tree(node, spacing=''):
    if isinstance(node, Leaf):
        print (spacing + "Predict", node.predictions)
        return
    print (spacing + str(node.question))#+str(node.entropy))
    print (spacing + '--> True:')
    print_tree(node.true_branch, spacing + "  ")
    print (spacing + '--> False:')
    print_tree(node.false_branch, spacing + "  ")


# In[43]:


tree=build_tree(dataset)
print_tree(tree)


# In[44]:


def classify(row, node):
    if isinstance(node, Leaf):
        return node.predictions
    if node.question.match(row):
        return classify(row, node.true_branch)
    else:
        return classify(row, node.false_branch)


# In[45]:


test=['Moderate','Cheap','Loud','City-Center','No','No']
classify(test,tree)


# In[ ]:




