#!/usr/bin/env python
# coding: utf-8

# In[46]:


from cvxopt import matrix as cvxopt_matrix
from cvxopt import solvers as cvxopt_solvers
import numpy as np
from numpy import linalg


# In[178]:


file=open('linsep.txt')
xdata=[]
ydata=[]
for r in file:
    row=r.strip().split(',')
    xdata.append(row[:-1])
    ydata.append(row[-1])
X=np.array(xdata,dtype=np.float32).astype(np.double)
Y_train=np.array(ydata,dtype=np.float32).astype(np.double)


# In[179]:


m,n = X.shape
y = Y_train.reshape(-1,1) * 1.
X_dash = y * X
H = np.dot(X_dash , X_dash.T) * 1.

#Converting into cvxopt format
P = cvxopt_matrix(H)
q = cvxopt_matrix(-np.ones((m, 1)))
G = cvxopt_matrix(-np.eye(m))
h = cvxopt_matrix(np.zeros(m))
A = cvxopt_matrix(y.reshape(1, -1))
b = cvxopt_matrix(np.zeros(1))

#Setting solver parameters (change default to decrease tolerance) 
cvxopt_solvers.options['show_progress'] = False
sol = cvxopt_solvers.qp(P, q, G, h, A, b)
alphas = np.array(sol['x'])
#w parameter in vectorized form
w = ((y * alphas).T @ X).reshape(-1,1)

#Selecting the set of indices S corresponding to non zero parameters
S = (alphas > 1e-4).flatten()

#Computing b
b = y[S] - np.dot(X[S], w)
Support_vectors=X[S]
#Display results
print('Support_vectors = ',Support_vectors)
print('w = ', w.flatten())
print('b = ', b[0])
print(f'Equation = {float(w[0])}*x1+{float(w[1])}*x2+{float(b[0])}')


# In[181]:


file=open('nonlinsep.txt')
xdata=[]
ydata=[]
for r in file:
    row=r.strip().split(',')
    xdata.append(row[:-1])
    ydata.append(row[-1])
X=np.array(xdata,dtype=np.float32).astype(np.double)
Y_non=np.array(ydata,dtype=np.float32).astype(np.double)
y = Y_non.reshape(-1,1) * 1.


# In[182]:


def linear_kernel(x1, x2):
    return np.dot(x1, x2)
def polynomial_kernel(x, y, p=3):
    return (1 + np.dot(x, y)) ** p


# In[198]:


n_samples, n_features = X.shape
K = np.zeros((n_samples, n_samples))
for i in range(n_samples):
    for j in range(n_samples):
        K[i,j] = polynomial_kernel(X[i], X[j])
C=1
P = cvxopt_matrix(np.outer(y,y) * K)
q = cvxopt_matrix(np.ones(n_samples) * -1)
A = cvxopt_matrix(y, (1,n_samples))
b = cvxopt_matrix(0.0)
tmp1 = np.diag(np.ones(n_samples) * -1)
tmp2 = np.identity(n_samples)
G = cvxopt_matrix(np.vstack((tmp1, tmp2)))
tmp1 = np.zeros(n_samples)
tmp2 = np.ones(n_samples) * C
h = cvxopt_matrix(np.hstack((tmp1, tmp2)))
solution = cvxopt_solvers.qp(P, q, G, h, A, b)
alphas=np.array(solution['x'])
S = (alphas > 1e-4).flatten()
ind = np.arange(len(alphas))[S]

a = alphas[S]
sv = X[S]
sv_y = y[S]
L=len(a)
print("%d support vectors out of %d points" % (L, n_samples))
print('Support_vectors = ',sv)


# In[199]:


# Intercept
b = 0
for n in range(L):
    b += sv_y[n]
    b -= np.sum(a * sv_y * K[ind[n],S])
b
#w = np.zeros(n_features)
#for n in range(L):
    #w += a[n] * sv_y[n] * sv[n]
#print(f'Equation = {float(w[0])}*x1+{float(w[1])}*x2+{float(b)}')


# In[206]:


y_predict = np.zeros(len(X))
for i in range(len(X)):
    s = 0
    for a_v, s_y, s_v in zip(a, sv_y, sv):
        s += a_v * s_y * polynomial_kernel(X[i], s_v)
    y_predict[i] = s
y_new=y_predict+b
y_new.reshape(-1,1)


# In[ ]:




