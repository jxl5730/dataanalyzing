#!/usr/bin/env python
# coding: utf-8

# In[16]:


import numpy as np
from sklearn.metrics import accuracy_score
import matplotlib.pyplot as plt


# In[5]:


file=open('classification.txt')
xdata=[]
ydata=[]
for r in file:
    x_data=['1']
    row=r.strip().split(',')
    x_data.extend(row[:-2])
    xdata.append(x_data)
    ydata.append(row[-2])
X_train=np.array(xdata,dtype=np.float32)
Y_train=np.array(ydata,dtype=np.float32)


# In[60]:


class Perceptron:
    def __init__(self):
        self.w=None
    def model(self,x):
        if np.dot(x,self.w)>=0:
            return 1
        else:
            return -1
    def predict(self,X):
        Y=[]
        for x in X:
            result=self.model(x)
            Y.append(result)
        return np.array(Y)
    def fit(self,X,Y,itr=1,alpha=0.01):
        self.w=np.ones(X.shape[1])
        while itr>0:
            for x,y in zip(X,Y):
                y_pred=self.model(x)
                if y==1 and y_pred==-1:
                    self.w=self.w+alpha*x
                elif y==-1 and y_pred==1:
                    self.w=self.w-alpha*x   
            accuracy = accuracy_score(self.predict(X), Y)
            if accuracy==1:
                chkptw = self.w
                break
        self.w = chkptw
        print(accuracy,self.w)
    


# In[59]:


perceptron=Perceptron()
wt_matrix=perceptron.fit(X_train,Y_train)
wt_matrix


# In[54]:


class Pocket:
    def __init__(self):
        self.w=None
    def model(self,x):
        if np.dot(x,self.w)>=0:
            return 1
        else:
            return -1
    def predict(self,X):
        Y=[]
        for x in X:
            result=self.model(x)
            Y.append(result)
        return np.array(Y)
    def fit(self,X,Y,itr=1,alpha=0.01):
        self.w=np.ones(X.shape[1])
        accuracy = {}
        misclassified={}
        max_accuracy = 0
        for i in range(itr):
            for x,y in zip(X,Y):
                y_pred=self.model(x)
                if y==1 and y_pred==-1:
                    self.w=self.w+alpha*x
                elif y==-1 and y_pred==1:
                    self.w=self.w-alpha*x   
            accuracy[i] = accuracy_score(self.predict(X), Y)
            misclassified[i]=len(Y)-accuracy_score(self.predict(X), Y,normalize=False)
            if (accuracy[i] > max_accuracy):
                max_accuracy = accuracy[i]
                chkptw = self.w
        self.w = chkptw
        mis = sorted(misclassified.items())
        mx, my = zip(*mis)
        plt.plot(mx,my)
        plt.xlabel("Iteration #")
        plt.ylabel("Misclass #")
        plt.show()
        print(max_accuracy,self.w)


# In[55]:


file=open('classification.txt')
xdata=[]
ydata=[]
for r in file:
    x_data=['1']
    row=r.strip().split(',')
    x_data.extend(row[:-2])
    xdata.append(x_data)
    ydata.append(row[-1])
X_train1=np.array(xdata,dtype=np.float32)
Y_train1=np.array(ydata,dtype=np.float32)


# In[57]:


pocket=Pocket()
wt_matrix=pocket.fit(X_train1,Y_train1,7000)
wt_matrix


# In[15]:





# In[ ]:




