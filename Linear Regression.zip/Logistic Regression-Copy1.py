#!/usr/bin/env python
# coding: utf-8

# In[41]:


import numpy as np
from sklearn.metrics import accuracy_score


# In[48]:


class LogisticRegression:
    def __init__(self):
        self.w=None
    def model(self,x):
        if np.dot(x,self.w)>=0:
            return 1
        else:
            return -1
    def predict(self,X):
        Y=[]
        for x in X:
            result=self.model(x)
            Y.append(result)
        return np.array(Y)
    def sigmoid(self,s):
        return 1/(1+np.exp(-s)) 
    def fit(self,X,Y,itr=7000,lr=0.01):
        self.w=np.zeros(X.shape[1])
        size=Y.size
        for i in range(itr):
            z = np.dot(X, self.w)
            h = self.sigmoid(z)
            gradient = np.dot(X.T, (h - Y)) /size
            self.w -=lr * gradient
        accuracy = accuracy_score(self.predict(X), Y)
        print(accuracy,self.w)


# In[49]:


file=open('classification.txt')
xdata=[]
ydata=[]
for r in file:
    x_data=['1']
    row=r.strip().split(',')
    x_data.extend(row[:-2])
    xdata.append(x_data)
    ydata.append(row[-1])
X_train=np.array(xdata,dtype=np.float32)
Y_train=np.array(ydata,dtype=np.float32)


# In[50]:


lgreg=LogisticRegression()
lgreg.fit(X_train,Y_train)


# In[ ]:





# In[ ]:




