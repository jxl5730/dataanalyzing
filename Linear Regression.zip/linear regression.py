#!/usr/bin/env python
# coding: utf-8

# In[2]:


import numpy as np


# In[4]:


file=open('linear-regression.txt')
xdata=[]
ydata=[]
for r in file:
    x_data=['1']
    row=r.strip().split(',')
    x_data.extend(row[:-1])
    xdata.append(x_data)
    ydata.append(row[-1])
X_train=np.array(xdata,dtype=np.float32)
Y_train=np.array(ydata,dtype=np.float32).reshape(len(ydata),1)
D=X_train.T
XtX = np.dot(D,X_train)
Xty = np.dot(D,Y_train)
w = np.linalg.solve(XtX,Xty)
w


# In[ ]:





# In[ ]:




