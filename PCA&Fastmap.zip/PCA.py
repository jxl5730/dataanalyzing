#!/usr/bin/env python
# coding: utf-8

# In[1]:


import numpy as np
import math
from matplotlib import pyplot as plt
#from sklearn.preprocessing import StandardScaler as sdscal


# In[2]:


file=open('pca-data.txt')
data=[]
for row in file:
    data.append((row.strip().split('\t')))
X=np.array(data,dtype=np.float32)
#X_std = sdscal().fit_transform(X)
X_cov_matrix=np.cov(X.T)


# In[3]:


eig_vals,eig_vects=np.linalg.eig(X_cov_matrix)
#eig_vals


# In[4]:


eig_pairs=[(np.abs(eig_vals[i]),eig_vects[:,i]) for i in range (len(eig_vals))]
eig_pairs.sort(key=lambda x:x[0], reverse=True)
#eig_pairs


# In[7]:


matrixV=np.hstack((eig_pairs[0][1].reshape(3,1),
                   eig_pairs[1][1].reshape(3,1)))
#matrixV


# In[15]:


Y=np.dot(X,matrixV)
Y


# In[16]:


'''
with plt.style.context('seaborn-whitegrid'):
    plt.figure(figsize=(6, 4))
    plt.scatter(Y[:,0],Y[:,1])
    plt.xlabel('Principal Component 1')
    plt.ylabel('Principal Component 2')
    plt.tight_layout()
    plt.show()
'''


# In[ ]:


'''
from sklearn.decomposition import PCA as sklearnPCA
sklearn_pca = sklearnPCA(n_components=2)
Y_sklearn = sklearn_pca.fit_transform(X_std)
'''

