#!/usr/bin/env python
# coding: utf-8

# In[14]:


import numpy as np
import math
import random
import matplotlib.pyplot as plt


# In[15]:


dist=np.zeros((11,11))
X = np.zeros((11,3))
itr=0
file=open('fastmap-data.txt')
data=[]
for row in file:
    data.append((row.strip().split('\t')))

for line in data:
    dist[int(line[0]),int(line[1])]=int(line[2])
    dist[int(line[1]),int(line[0])]=int(line[2])
#dist


# In[16]:


words=[]
f = open('fastmap-wordlist.txt')
line = f.readline()
##initialize 2-D arrays
while line:
    words.append(line.splitlines())
    line = f.readline() 
f.close()


# In[17]:


def distance(a,b,itr):
    if(itr==1):
        return dist[a][b]   
    else:
        newdist=(math.pow(distance(a,b,itr-1),2)-(math.pow(X[a][itr-1]-X[b][itr-1],2)))
        return (math.sqrt(newdist))


# In[18]:


def findfurthestObject(itr):
    count = 0
    globalA = 0
    globalB = 0
    globalMax = 0
    b = random.randint(1,10) #this returns a random integer in the range of inclusive (1-10)
    while count<10:
        localMax = 0;
        for j in range(1, 11):
            d=distance(b, j, itr)
            if d>localMax:
                localMax=d
                a=j
# If the furthest pair of objects is not unique, please use the one that includes the
# smallest object ID.
        if localMax>globalMax:
            globalMax=localMax
            globalA = a
            globalB = b
        elif localMax==globalMax:
            cur_min = min(a,b)
            g_min = min(globalA,globalB)
            if cur_min<g_min:
                globalA = a
                globalB = b
        b=a
        count+=1
    # Return the point with lower id value as origin.
    return (globalA,globalB) if globalA<globalB else (globalB,globalA)
                


# In[19]:


def Fastmap(k):
    global itr
    if k<=0:
        return
    else:
        itr+=1
    a,b=findfurthestObject(itr)
    if distance(a,b,itr)==0:
        X[:,itr]=0
    for i in range(1,11):
        if i==a:
            X[i,itr]=0
        elif i==b:
            X[i,itr]=distance(a,b,itr)
        else:
            X[i,itr]=(math.pow(distance(a,i,itr),2)
                       +math.pow(distance(a,b,itr),2)-math.pow(distance(b,i,itr),2))/(2*distance(a,b,itr))
    Fastmap(k-1)
    


# In[20]:


Fastmap(2)


# In[21]:


data=X[1:,1:]
data


# In[10]:


fig, ax = plt.subplots()
for i in range(10):
    ax.scatter(data[i,0], data[i,1])
    ax.annotate(words[i], (data[i,0], data[i,1]))
plt.show()

