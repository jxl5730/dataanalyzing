#!/usr/bin/env python
# coding: utf-8

# In[8]:


import matplotlib.pyplot as plt
from matplotlib import style
style.use('fivethirtyeight')
import numpy as np
from scipy.stats import multivariate_normal


class GMM:

    def __init__(self,X,number_of_sources,iterations):
        self.iterations = iterations
        self.number_of_sources = number_of_sources
        self.X = X
        self.mu = None
        self.pi = None
        self.cov = None
        
    
    def fit(self):        
                    
        """ Set the initial mu, covariance and pi values"""
        # This is a nxm matrix since we assume n sources (n Gaussians) where each has m dimensions
        self.mu = np.random.randint(min(self.X[:,0]),max(self.X[:,0]),size=(self.number_of_sources,len(self.X[0]))) 
        self.cov = np.zeros((self.number_of_sources,len(X[0]),len(X[0])))
        for dim in range(len(self.cov)):
            np.fill_diagonal(self.cov[dim],5)


        self.pi = np.ones(self.number_of_sources)/self.number_of_sources # Are "Fractions"
        log_likelihoods = [] 
        
        for i in range(self.iterations):               

            """E Step"""
            r_ic = np.zeros((len(self.X),len(self.cov)))
            

            for m,co,p,r in zip(self.mu,self.cov,self.pi,range(len(r_ic[0]))):
                mn = multivariate_normal(mean=m,cov=co)
                r_ic[:,r] = p*mn.pdf(self.X)/np.sum([pi_c*multivariate_normal(mean=mu_c,cov=cov_c).pdf(X) 
                            for pi_c,mu_c,cov_c in zip(self.pi,self.mu,self.cov)],axis=0)
        

            """M Step"""

         
            self.mu = []
            self.cov = []
            self.pi = []
            log_likelihood = []

            for c in range(len(r_ic[0])):
                m_c = np.sum(r_ic[:,c],axis=0)
                mu_c = (1/m_c)*np.sum(self.X*r_ic[:,c].reshape(len(self.X),1),axis=0)
                self.mu.append(mu_c)
                self.cov.append(((1/m_c)*np.dot((np.array(r_ic[:,c]).reshape(len(self.X),1)
                                                 *(self.X-mu_c)).T,(self.X-mu_c)))) 
                self.pi.append(m_c/np.sum(r_ic)) 

                       
            """Log likelihood"""
            log_likelihoods.append(np.log(np.sum([k*multivariate_normal(self.mu[i],self.cov[j]).pdf(X) 
                                                  for k,i,j in zip(self.pi,range(len(self.mu)),range(len(self.cov)))])))

        
        parameters={}
        parameters['mu']=[]
        parameters['cov']=[]
        parameters['pi']=[]
        
        for m in self.mu:
            parameters['mu'].append(m)
        for c in self.cov:    
            parameters['cov'].append(c)
        for p in self.pi:    
            parameters['pi'].append(p)
        for i in range(3):
            print(parameters['mu'][i],parameters['cov'][i],parameters['pi'][i])


# In[9]:


file=open('clusters.txt')


# In[10]:


data=[]
for row in file:
    data.append((row.strip().split(',')))
X=np.array(data,dtype=np.float32)


# In[11]:


GMM = GMM(X,3,50)     
GMM.fit()


# In[18]:





# In[ ]:




