#!/usr/bin/env python
# coding: utf-8

# In[3]:


#import matplotlib.pyplot as plt
#from matplotlib import style
import numpy as np
#style.use('ggplot')
#colors=10*['b','g','r','c','k']


# In[4]:


class K_means:
    def __init__(self,k,tol=0.001,max_iter=300):
        self.k=k
        self.tol=tol
        self.max_iter=max_iter
    def fit(self,data):
        self.centroids={}
        for i in range(self.k):
            self.centroids[i]=data[i]
        for i in range(self.max_iter):
            self.clusters={}
            for i in range(self.k):
                self.clusters[i]=[]
            for featureset in data:
                distances=[np.linalg.norm(featureset-self.centroids[centroid]) for centroid in self.centroids]
                cluster=distances.index(min(distances))
                self.clusters[cluster].append(featureset)
            pre_centroids=dict(self.centroids)
            for cluster in self.clusters:
                self.centroids[cluster]=np.average(self.clusters[cluster],axis=0)
            optimized=True
            for c in self.centroids:
                original_centroid=pre_centroids[c]
                current_centroid=self.centroids[c]
                if np.sum((current_centroid-original_centroid)/original_centroid*100.0)>self.tol:
                    optimized=False
                if optimized:
                    break
                    
                    


# In[5]:


file=open('clusters.txt')
data=[]
for row in file:
    data.append((row.strip().split(',')))
dataset=np.array(data,dtype=np.float32)


# In[6]:


model=K_means(3)
model.fit(dataset)


# In[7]:


print(model.centroids)


# In[118]:


#for c in model.centroids:
    #plt.scatter(model.centroids[c][0],model.centroids[c][1],marker='o',color='k',s=150,linewidth=5)
#for c in model.clusters:
    #color=colors[c]
    #for featureset in model.clusters[c]:
        #plt.scatter(featureset[0],featureset[1],marker='x',color=color,s=150,linewidth=5)
#plt.show()


# In[ ]:




